#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <pthread.h>
#include <assert.h>
#include <string.h>


#define MAX_UNIQUE 128	//Number of ASCII characters

FILE *fp;	//File to read to input
FILE *fw;	//File to write huffman encoding in
char c;
int* ASCII;	//The array for checking frequency of characters an storing in array
int count =0; //Maintaining count of unique characters
int* temp_arr; //Store the Huffman Code for each unique character
int total; //Size of huffman tree
char new = '\n';
int  n; //Number of threads
pthread_mutex_t * locks;
pthread_mutex_t * locks2;

struct Node{
		char value;
		int freq;
		int code[128];
		int code_len;
		struct Node* left;
		struct Node* right;
};

typedef struct _threadarg{
	int start;
	int end;
	int thread_index;
} threadarg;

struct Node* root; //Used to point to root 
struct Node* arr; //Used to store sorted frequencies
struct Node* ptr; //Used to traverse the tree


int isLeaf(struct Node *node) {

  if ((node->left ==NULL) && (node->right == NULL))
  {
  	return 1;
  }
  
  return 0;
}
void writeFile(struct Node *node, int arr[], int top) {

  if (node->left) {
    arr[top] = 0;
    writeFile(node->left, arr, top + 1);
  }
  if (node->right) {
    arr[top] = 1;
    writeFile(node->right, arr, top + 1);
  }
  
  if ((node->left ==NULL) && (node->right == NULL)) 
  {
  	total = top;
  	//printf("%c ", node->value);
   	fprintf(fw, "%c", node->value);
   	node->code_len = top;
    for (int i = 0; i < top; ++i)
    {	
    	node->code[i] = arr[i];
    	//printf("%d", arr[i]);
    	fprintf(fw, "%d", arr[i]);
    }
    	//printf("\n");
	fprintf(fw, "\n");
  }
}
int counter =0;

void getValue(struct Node* node, char t) {

	if (node->left) {
		getValue(node->left, t);
	}
	
	if (node->right) {
		getValue(node->right, t);
	}
	if ((node->left ==NULL) && (node->right == NULL))
	{	
		if (node->value ==t)
		{
			
			for (int i = 0; i < node->code_len; ++i)
			{	
				//fprintf(fw, "%d", node->code[i]);
				fwrite(&node->code[i], 1, 1, fw);
				
			}
			//printf("%c", node->value);
			fwrite(&new, 1, 1, fw);
			//fprintf(fw, "\n");
		}
		return;
	}
	//getValue(node->right, t);
	//getValue(node->left, t);

}

void encodeFile (struct Node* node, FILE* fr)
{
	char text;
	while (text != EOF)	//Reading the values
  	{	
  	 	text = (char)fgetc(fr);
  	 	//printf("%c", text);
  	 	getValue(node, text);
  	}
}

void* readFreq(void *farg)
{
	threadarg* arg = (threadarg*)farg;
	pthread_mutex_lock(&locks[arg->thread_index]);
	
	int i =arg->start;
	while (i!=arg->end) {	//Critical section
		c = (char)fgetc(fp);
		if (c<0)
		{
			i++;
			continue;
		}
  	 	if (ASCII[(int)c] ==0)
  	 	{
  	 		count++;
  	 	}
  	 	ASCII[(int)c]++;
  	 	i++;
	}
	if (arg->thread_index<n-1){
		pthread_mutex_unlock(&locks[arg->thread_index+1]);
	}
}

void* buildTree(void* harg)
{
	threadarg* arg = (threadarg*)harg;
	pthread_mutex_lock(&locks2[arg->thread_index]);
	
	for (int i=arg->start; i<arg->end; i++)	//Critical section
	{
		struct Node* parent = malloc(sizeof *parent);
		if (ptr->freq <= arr[i].freq)
		{	
			parent->left = ptr;
			parent->right = &arr[i];
		}
		else 
		{	
			parent->right = ptr;
			parent->left = &arr[i];
		}
			
		parent->freq = parent->left->freq + parent->right->freq;
		ptr = parent;
	}
	if (arg->thread_index<n-1){
		pthread_mutex_unlock(&locks2[arg->thread_index+1]);
	}
}


int main(int argc, char *argv[])
{
	if (argc !=4)	//Checking for arguments
	{
		printf("Error! Invalid arguments.\n");
		printf("zip <text file name> <number of threads> <output file name>\n\n");
		exit(EXIT_FAILURE);
	}
	
	n = atoi(argv[2]);	//Allocating memory for arrays
	if (n<=0)
	{
		printf("Invalid Thread Value\n");
		exit(EXIT_FAILURE);
	}
	ASCII = malloc(sizeof(int)*MAX_UNIQUE);	//Initialzing array, 128 characters are the limit
	temp_arr = malloc(sizeof(int)*(128));	
	if ((ASCII == NULL) || (temp_arr==NULL))	//Malloc check
	{
		perror("Error!");
		exit(EXIT_FAILURE);
	}
	char str[40];
	
	strcpy(str, argv[3]);
	strcat(str, "_encoded.bin");
	fw =fopen(str, "w");	//File to write huffman code
	if (fw == NULL) 
		{
			printf("Cannot open file\n");
			exit(EXIT_FAILURE);
		}
	fp = fopen (argv[1],"r");	//Opening file to read
	 if (fp == NULL)
	 {
       	 	 perror("Error! File not Opened");
       	 	 return (-1);
  	 }
  	 fseek(fp, 0L, SEEK_END);
  	 int filesize = ftell(fp); //Size of input file
  	 rewind(fp);
  	 threadarg* marg = (threadarg*) malloc(sizeof(threadarg) * n);
  	 pthread_t* thread =(pthread_t*) malloc(sizeof(pthread_t) * n); //Threads for reading frequency
  	 locks = malloc(sizeof(pthread_mutex_t)*n); 
  	 locks2 = malloc(sizeof(pthread_mutex_t)*n); 
  	 if (thread == NULL || marg == NULL || locks == NULL || locks2 == NULL)
	 {
       	 	 perror("Error!");
       	 	 exit(EXIT_FAILURE);
  	 }
  	 int rc;
	//initializing all locks and locking trhem
  	 for(int i =0; i< n; i++)  {
		rc = pthread_mutex_init(&locks[i], NULL);
		assert(rc==0);
		pthread_mutex_lock(&locks[i]);
	}
	pthread_mutex_unlock(&locks[0]); //unlocking the first lock
  	 float size = (float)filesize/n;
  	 int chunk = ceil((float)size);
	
	//Setting up thread arguments
	for(int i =0; i < filesize; i =i+chunk){

		int index = (int)i/chunk;
		marg[index].start = i;
		marg[index].end = i + chunk < filesize ? i + chunk : filesize;
		marg[index].thread_index = index;
		//printf("start %d, end %d\n", marg[index].start, marg[index].end);
		
	}
	for (int i =0; i< n; i++)	//Finding the frequency using threads and placing in respective index in ASCII. i.e if a appears 5 times, ASCII[32]=5
	{
		if((pthread_create(&thread[i], NULL, readFreq, &marg[i])) !=0)
		{
			printf("Error! Thread not created\n");
		}
	}
	
	for (int i =0; i< n; i++){
		if (pthread_join(thread[i], NULL) !=0)
		{
			printf("Error! Threads not joined ");
			exit(EXIT_FAILURE);
		}
	}
	count++;	//Since you're not using c!=EOF, and using i!=arg->end, this is needed
	arr = malloc(sizeof *arr * count); 
		
	if (arr == NULL)
	{
		perror("ERROR!");
		exit(EXIT_FAILURE);
	}

	struct Node* temp = malloc(sizeof *temp);
	if (temp == NULL)
	{
		perror("ERROR!");
		exit(EXIT_FAILURE);
	}
	int x;
	int j=0;

	for (x = 0; x < 128; x++)	//Placing the values in struct array
	{
		if (ASCII[x]!= 0)
	  	 	{
	  	 		arr[j].value = x;
	  	 		arr[j].freq = ASCII[x];
	  	 		arr[j].left = NULL;
	  	 		arr[j].right = NULL;
	  	 		j++;
	  	 	}
	}
  	 for (int i=0; i<j-1; i++)	//Sorting based on frequency
  	 {
  	 	for (int k=0; k<j-i-1; k++)
  	 	{
  	 		if (arr[k].freq > arr[k + 1].freq)
  	 		{
  	 			temp->value = arr[k].value;
  	 			temp->freq = arr[k].freq;
  				arr[k].value = arr[k+1].value;
	 			arr[k].freq = arr[k+1].freq;
  	 			arr[k+1].value = temp->value;
  	 			arr[k+1].freq = temp->freq;
  	 		}
  	 	}
  	 }
  	 
  	//Setting up huffman thread arguments
  	size = (float)count/n;
  	chunk = ceil((float)size);
	for(int i =0; i < count; i =i+chunk){
		int index = (int)i/chunk;
		marg[index].start = i;
		marg[index].end = i + chunk < count ? i + chunk : count;
		marg[index].thread_index = index;
		//printf("start %d, end %d\n", marg[index].start, marg[index].end);
	}
	
	struct Node* node = malloc(sizeof *temp);	//Setting the deepest leaf nodes
	node->left = &arr[0];
	node->right = &arr[1];
	node->freq = node->left->freq + node->right->freq;
	ptr = malloc(sizeof *ptr);
	
	ptr = node;
	for(int i =0; i< n; i++)  {
		rc = pthread_mutex_init(&locks2[i], NULL);
		assert(rc==0);
		pthread_mutex_lock(&locks2[i]);
	}
	
	pthread_mutex_unlock(&locks2[0]); //unlocking the first lock
	//Determining the huffman encoding
  	for (int i =0; i< n; i++)	{
		if((pthread_create(&thread[i], NULL, buildTree, &marg[i])) !=0)
		{
			
			printf("Error! Thread not created\n");
		}
	}
	
	for (int i =0; i< n; i++){
		if (pthread_join(thread[i], NULL) !=0)
		{
			printf("Error! Threads not joined ");
			exit(EXIT_FAILURE);
		}
	}
	
	root = ptr;
	//treeTraversal(root);
	
	writeFile(root, temp_arr, 0);
	fclose(fw);
	fw =fopen(argv[3], "w");	
	FILE* fr = fopen (argv[1],"r");	//Opening file to read
	if (fr == NULL || fw == NULL)
	{
       	 	 perror("Error! File not Opened");
       	 	 exit(EXIT_FAILURE);
  	}
  	
  	encodeFile(root, fr);
  	
  	//Preventing memory leak
  	fclose(fr);
  	fclose(fw);
  	fclose(fp);
  	
  	 free(ASCII);
  	 free(temp_arr);
  	 free(marg);
  	 free(thread);
  	 free(ptr);
  	 free(node);
  	 free(temp);
  	 free(arr);
  	 free(locks);
  	 free(locks2);
  	 exit(0);
  	 
}

