#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>

int n; //Number of threads
pthread_mutex_t * locks;
int* temp;
FILE* file;
FILE* fw;
int* ASCII;
int* cap;

struct Node{
		char value;
		int freq;
		int code[128];
		int code_len;
		struct Node* left;
		struct Node* right;
};

typedef struct _threadarg{
	int start;
	int end;
	int thread_index;
} threadarg;

void* decode(void* farg)
{
	threadarg* arg = (threadarg*)farg;
	int count;
	pthread_mutex_lock(&locks[arg->thread_index]);
	
	int i =0;
	int check = 1;
	for (int j=arg->start; j<arg->end; j++)//Decoding from file
   {	
    	fread(&temp[i], 1, 1, file);
    	count++;
    	if (temp[i] == 10) //Found one complete code
    	{
    		for (int x=0; x<128; x++)
    		{
    			if (i == cap[x]) //Found the one of same length
    			{
    				
    				for (int y=0; y<i; y++)
    				{
    					if (temp[y] != ASCII[x*128 + y])
    					{
    						printf("%c", (char)x);
    						check = 0;
    					}
    				}
    				if (check ==1)	//This ensures that the codes match
    					{
							fprintf(fw, "%c", (char)x);
    					} 
    				check =1;
    			}
    		}
    		i=0;
    		continue;
    	}
    	i++;
    }
    
    if (arg->thread_index<n-1){
		pthread_mutex_unlock(&locks[arg->thread_index+1]);
	}
}
int main(int argc, char *argv[])
{
	
	if (argc !=4)	//Checking for arguments
	{
		printf("Error! Invalid arguments.\n");
		printf("unzip <zipped file name> <number of threads> <output file name>\n\n");
		exit(EXIT_FAILURE);
	}
	n = atoi(argv[2]); //Threads number
	if (n<0)
	{
		printf("Invalid Thread Value\n");
		exit(EXIT_FAILURE);
	}
	char c;
	char value;
	int index;
	int index2;
	ASCII = malloc(sizeof(int)*128*128);	//To store the code of all characters
	cap = malloc(sizeof(int)*128);	//To store the length of codes
	temp = malloc(sizeof(int)*128); //To store code while reading from encoded file
	threadarg* marg = (threadarg*) malloc(sizeof(threadarg) * n);
  	pthread_t* thread =(pthread_t*) malloc(sizeof(pthread_t) * n);
  	locks = malloc(sizeof(pthread_mutex_t)*n); 
  	
  	if (thread == NULL || marg == NULL || locks == NULL)
	 {
       	 	 perror("Error! Threads not initialized");
       	 	 exit(EXIT_FAILURE);
  	 }
	
	char str[40];
	strcpy(str, argv[1]);
	strcat(str, "_encoded.bin");
	
	FILE* fp =fopen(str, "r");
	if (fp == NULL) 
		{
			printf("Cannot open file\n");
			exit(EXIT_FAILURE);
		}
	
  	 
  	 while (c != EOF)	//Reading the values
  	 {
  	 	c = (char)fgetc(fp);
  	 	if (((int)c !=48) && ((int)c !=49))
  	 	{
  	 		index2= 0;
  	 		index = (int)c;
  	 		continue;
  	 	}
  	 	if ((int)c ==48)
  	 	{	
  	 		ASCII[index*128 + index2] = 0;
  	 	}
  	 	
  	 	if ((int)c ==49)
  	 	{
  	 		ASCII[index*128 + index2] = 1;
  	 	}
  	 	cap[index] += 1;
  	 	
  	 	index2++;
  	 }
	
	fclose(fp);  
  	 
  	 for (int i=0; i<128; i++)	//Printing 
  	 {
  	 	//printf("%c | ", (char)i);
  	 	for (int j=0; j<cap[(int)i]; j++)
  	 	{
  	 		//printf("%d", ASCII[i*128 + j]);
  	 	}
  	 	//printf("\n");
  	 }
	
	fw =fopen(argv[3], "w");	
    file = fopen(argv[1], "r"); /* should check the result */
    if (file == NULL || fw == NULL) 
		{
			printf("Cannot open file\n");
			exit(EXIT_FAILURE);
		}

    char line[10];
    int i=0;
    
    fseek(file, 0L, SEEK_END);
    int filesize = ftell(file); //Size of input file
    rewind(file);
    
     int rc;
	//initializing all locks and locking trhem
  	 for(int i =0; i< n; i++)  {
		rc = pthread_mutex_init(&locks[i], NULL);
		assert(rc==0);
		pthread_mutex_lock(&locks[i]);
	}
	pthread_mutex_unlock(&locks[0]); //unlocking the first lock
	
	float size = (float)filesize/n;
  	int chunk = ceil((float)size);
    
      for(int i =0; i < filesize; i =i+chunk){
		int index = (int)i/chunk;
		marg[index].start = i;
		marg[index].end = i + chunk < filesize ? i + chunk : filesize;
		marg[index].thread_index = index;
		//printf("start %d, end %d\n", marg[index].start, marg[index].end);
	}
	
	for (int i =0; i< n; i++)	//Finding the frequency using threads and placing in respective index in ASCII. i.e if a appears 5 times, ASCII[32]=5
	{
		if((pthread_create(&thread[i], NULL, decode, &marg[i])) !=0)
		{
			printf("Error! Thread not created\n");
		}
	}
	
	for (int i =0; i< n; i++){
		if (pthread_join(thread[i], NULL) !=0)
		{
			printf("Error! Threads not joined ");
			exit(EXIT_FAILURE);
		}
	}

    	fclose(file);
	fclose(fw);
	
  	free(ASCII);
  	free(cap);
  	free(temp);
  	free(marg);
  	free(thread);
  	free(locks);

    exit(0);
}

